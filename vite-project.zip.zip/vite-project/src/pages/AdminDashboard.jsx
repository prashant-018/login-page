import React from 'react';

const AdminDashboard = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-purple-800 flex items-center justify-center px-4">
      <div className="bg-white rounded-xl shadow-xl p-10 max-w-xl w-full text-center">
        <h1 className="text-3xl font-bold text-purple-700 mb-4">Admin Dashboard</h1>
        <p className="text-gray-700 text-lg">
          Welcome, <span className="font-semibold">Admin</span>! Here you can manage the system, users, and data.
        </p>

        <div className="mt-6 grid grid-cols-2 gap-4">
          <button className="bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition">
            Manage Users
          </button>
          <button className="bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition">
            View Reports
          </button>
          <button className="bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition">
            System Settings
          </button>
          <button className="bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition">
            Logout
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
