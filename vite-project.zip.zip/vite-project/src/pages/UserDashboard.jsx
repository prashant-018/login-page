import React from 'react';

const UserDashboard = () => {
  return (
    <div className="min-h-screen bg-blue-50 flex items-center justify-center px-4">
      <div className="bg-white p-8 rounded-2xl shadow-xl max-w-xl w-full text-center">
        <h1 className="text-3xl font-bold text-blue-700 mb-4">User Dashboard</h1>
        <p className="text-gray-700">
          👋 Welcome, User! Here you can see your profile and activities.
        </p>
      </div>
    </div>
  );
};

export default UserDashboard;
