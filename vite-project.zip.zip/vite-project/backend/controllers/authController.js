// D:\login page\vite-project\backend\routes\authRoutes.js

const express = require('express');
const router = express.Router();
const { register, login } = require('../controllers/authController'); // Correctly import functions
const { protect, adminOnly } = require('../middlewares/authMiddleware'); 
router.post('/register', register); // This 
router.post('/login', login);       // This 
module.exports = router;