// D:\login page\vite-project\backend\server.js

// Load environment variables from .env file
require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors'); // For handling Cross-Origin requests

// Import your authentication routes
const authRoutes = require('./routes/authRoutes');

const app = express();

// --- Middleware ---

app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:5173', // Your Vite frontend's URL
    credentials: true // Important if you're sending cookies, session, or auth headers
}));


app.use(express.json());


app.use(express.urlencoded({ extended: true }));



app.use('/api/auth', authRoutes);


app.get('/', (req, res) => {
    res.send('Backend server is alive and running!');
});



mongoose.connect(process.env.MONGO_URI)
    .then(() => {
        console.log('MongoDB connected successfully!');

     
        const PORT = process.env.PORT || 5000;
        app.listen(PORT, () => {
            console.log(`Server started on port ${PORT}`);
            console.log(`Frontend should be connecting to: ${process.env.FRONTEND_URL || 'http://localhost:5173'}`);
        });
    })
    .catch(err => {
    
        console.error('MongoDB connection error:', err.message);
   
        process.exit(1);
    });


app.use((err, req, res, next) => {
    console.error(err.stack); // Log the stack trace to the console
    res.status(500).send('Something went wrong on the server!');
});