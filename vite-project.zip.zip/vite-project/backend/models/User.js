// D:\login page\vite-project\backend\models\User.js

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs'); // Don't forget to install bcryptjs if you haven't: npm install bcryptjs

const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true // Added required: true as a common practice for usernames
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true, // Store emails in lowercase to prevent issues with case sensitivity
        trim: true,      // Remove whitespace from both ends
        match: [/^[\w-]+(?:\.[\w-]+)*@(?:[\w-]+\.)+[a-zA-Z]{2,7}$/, 'Please fill a valid email address'] // Basic email regex validation
    },
    password: {
        type: String,
        required: true,
        minlength: 6 // Added minimum length for password for basic security
    },
    role: {
        type: String,
        enum: ['user', 'admin'], // Ensures role is either 'user' or 'admin'
        default: 'user'
    },
    createdAt: { // Added a timestamp for when the user was created
        type: Date,
        default: Date.now
    }
});

// Pre-save hook to hash the password before saving a user
// 'pre' middleware executes before 'save' operations
userSchema.pre('save', async function(next) {
    // Only hash the password if it has been modified (or is new)
    if (!this.isModified('password')) {
        return next();
    }

    // Generate a salt and hash the password
    const salt = await bcrypt.genSalt(10); // 10 is a good default for salt rounds
    this.password = await bcrypt.hash(this.password, salt);
    next(); // Continue with the save operation
});

// Optional: Add a method to compare passwords (useful in authController)
userSchema.methods.matchPassword = async function(enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
};


module.exports = mongoose.model('User', userSchema);