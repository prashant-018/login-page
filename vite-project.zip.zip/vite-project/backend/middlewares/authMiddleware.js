// D:\login page\vite-project\backend\middlewares\authMiddleware.js

const jwt = require('jsonwebtoken');

/**
 * Middleware to protect routes: verifies JWT token and attaches user info to request.
 * Requires: JWT_SECRET in .env
 * Assumes: token is sent in 'Authorization' header as 'Bearer YOUR_TOKEN_STRING'
 */
exports.protect = (req, res, next) => {
    // 1. Check for Authorization header
    // The convention is 'Bearer YOUR_TOKEN_STRING'
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ message: 'Access denied. No token or invalid token format provided.' });
    }

    // Extract the token string (remove 'Bearer ')
    const token = authHeader.split(' ')[1];

    if (!token) { // Double check, though startsWith should catch this usually
        return res.status(401).json({ message: 'Access denied. Token not found.' });
    }

    try {
        // Verify the token using your secret
        // The decoded payload contains what you signed into the token (e.g., { userId: user._id, role: user.role })
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // Attach the decoded user payload to the request object
        // This makes user info available in subsequent middleware or route handlers (e.g., req.user.userId, req.user.role)
        req.user = decoded; // The user object here typically contains { userId, role }

        // Pass control to the next middleware or route handler
        next();
    } catch (err) {
        // Log the error for debugging purposes (e.g., TokenExpiredError, JsonWebTokenError)
        console.error('JWT verification error:', err.message);

        // Respond with a 401 Unauthorized status for invalid tokens
        return res.status(401).json({ message: 'Invalid or expired token.' });
    }
};

/**
 * Middleware to restrict access to admin users only.
 * Requires: protect middleware to run before this, populating req.user.
 * Assumes: req.user object has a 'role' property.
 */
exports.adminOnly = (req, res, next) => {
    // Ensure req.user exists (i.e., protect middleware ran successfully) and has a role
    if (!req.user || !req.user.role) {
        // This case should ideally not happen if 'protect' runs first,
        // but it's a good safeguard for robustness.
        return res.status(403).json({ message: 'Forbidden. User information not available.' });
    }

    // Check if the user's role is 'admin'
    if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Forbidden. Admin access required.' });
    }

    // If the user is an admin, pass control to the next middleware or route handler
    next();
};